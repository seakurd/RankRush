package com.rankrush.app;

import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;

public final class GameView extends View {
    public interface Listener { void finished(int score, int[] reactions); }
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random;
    private final Listener listener;
    private boolean running, target, tooEarly;
    private long shownAt;
    private int round, total;
    private final int[] reactions = new int[10];

    public GameView(android.content.Context c, long seed, Listener listener) {
        super(c); this.listener = listener; random = new Random(seed); setFocusable(true);
    }

    public void start() {
        running = true; target = false; tooEarly = false; round = 0; total = 0;
        nextRound(); invalidate();
    }

    private void nextRound() {
        if (round >= 10) {
            running = false; listener.finished(Math.max(1, total / 10), reactions.clone()); return;
        }
        target = false; tooEarly = false;
        int delay = 900 + random.nextInt(1500);
        handler.postDelayed(() -> { if (!running) return; target = true; shownAt = System.nanoTime(); invalidate(); }, delay);
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w = getWidth(), h = getHeight();
        c.drawColor(Color.rgb(9, 10, 18));
        p.setTypeface(Typeface.create("sans", Typeface.BOLD)); p.setTextAlign(Paint.Align.CENTER);
        p.setColor(Color.WHITE); p.setTextSize(dp(18));
        c.drawText("ROUND " + (round + 1) + " / 10", w/2f, dp(55), p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(dp(14)); p.setColor(Color.LTGRAY);
        c.drawText(target ? "TAP NOW" : "WAIT FOR THE PULSE", w/2f, dp(82), p);
        float cx=w/2f, cy=h/2f, r=dp(92);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(8));
        p.setColor(target ? Color.WHITE : Color.rgb(90,90,110)); c.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.FILL); p.setColor(target ? Color.WHITE : Color.rgb(28,30,45)); c.drawCircle(cx,cy,r-dp(16),p);
        if (tooEarly) {
            p.setColor(Color.rgb(255,120,130)); p.setTextSize(dp(16)); c.drawText("TOO EARLY  +600MS", cx, cy+r+dp(46), p);
        }
        p.setColor(Color.DKGRAY); p.setTextSize(dp(12)); c.drawText("LOWER IS BETTER", cx, h-dp(28), p);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP || !running) return true;
        float cx=getWidth()/2f, cy=getHeight()/2f;
        if (Math.hypot(e.getX()-cx, e.getY()-cy) > dp(130)) return true;
        if (!target) {
            tooEarly=true; total += 600; reactions[round]=600; target=false; round++; handler.removeCallbacksAndMessages(null); postDelayed(this::nextRound, 300); invalidate();
        } else {
            int ms=(int)((System.nanoTime()-shownAt)/1_000_000L); ms=Math.max(90, Math.min(ms, 999));
            reactions[round]=ms; total += ms; target=false; round++; handler.removeCallbacksAndMessages(null); postDelayed(this::nextRound, 240); invalidate();
        }
        return true;
    }
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
}
