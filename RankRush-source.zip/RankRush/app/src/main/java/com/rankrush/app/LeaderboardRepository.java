package com.rankrush.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public final class LeaderboardRepository {
    public static final class Entry {
        public final String name, country;
        public final int score;
        public final boolean me;
        public Entry(String name, String country, int score, boolean me) {
            this.name = name; this.country = country; this.score = score; this.me = me;
        }
    }

    private static final String PREFS = "rankrush";
    private static final String KEY_BEST = "best";
    private static final String KEY_LAST_DATE = "lastDate";
    private static final String KEY_STREAK = "streak";
    private final Context context;

    public LeaderboardRepository(Context context) { this.context = context.getApplicationContext(); }

    public int getBest() { return context.getSharedPreferences(PREFS, 0).getInt(KEY_BEST, 0); }
    public int getStreak() { return context.getSharedPreferences(PREFS, 0).getInt(KEY_STREAK, 0); }
    public String getLastDate() { return context.getSharedPreferences(PREFS, 0).getString(KEY_LAST_DATE, ""); }

    public void saveScore(int score, String today) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREFS, 0);
        int old = p.getInt(KEY_BEST, 0);
        int best = old == 0 ? score : Math.min(old, score);
        String last = p.getString(KEY_LAST_DATE, "");
        int streak = p.getInt(KEY_STREAK, 0);
        if (last.isEmpty()) streak = 1;
        else if (isYesterday(last, today)) streak++;
        else if (!last.equals(today)) streak = 1;
        p.edit().putInt(KEY_BEST, best).putString(KEY_LAST_DATE, today).putInt(KEY_STREAK, streak).apply();
    }

    private boolean isYesterday(String last, String today) {
        try {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
            f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            java.util.Date a = f.parse(last);
            java.util.Date b = f.parse(today);
            return b.getTime() - a.getTime() == 86400000L;
        } catch (Exception e) { return false; }
    }

    public List<Entry> getDemoLeaderboard(String today, int userScore) {
        long seed = today.hashCode() * 1103515245L + 12345L;
        Random r = new Random(seed);
        String[][] people = {
                {"Mia","🇺🇸"},{"Noah","🇬🇧"},{"Ava","🇨🇦"},{"Liam","🇦🇺"},{"Sofia","🇪🇸"},
                {"Yuki","🇯🇵"},{"Leo","🇩🇪"},{"Nora","🇳🇱"},{"Adam","🇫🇷"},{"Zara","🇸🇪"},
                {"Aria","🇮🇹"},{"Luca","🇵🇹"},{"Mina","🇰🇷"},{"Eli","🇧🇷"},{"Aya","🇹🇷"},
                {"Ivy","🇳🇴"},{"Omar","🇲🇦"},{"Lena","🇵🇱"},{"Kai","🇸🇬"},{"Dani","🇲🇽"}
        };
        ArrayList<Entry> rows = new ArrayList<>();
        for (int i = 0; i < people.length; i++) {
            int score = 185 + r.nextInt(185) + (i % 4 == 0 ? -20 : 0);
            rows.add(new Entry(people[i][0], people[i][1], Math.max(140, score), false));
        }
        if (userScore > 0) rows.add(new Entry("YOU", countryEmoji(), userScore, true));
        rows.sort((a,b) -> Integer.compare(a.score,b.score));
        return rows;
    }

    public int rankFor(String today, int score) {
        int rank = 1;
        for (Entry e : getDemoLeaderboard(today, 0)) if (e.score < score) rank++;
        return rank;
    }

    private String countryEmoji() {
        String cc = Locale.getDefault().getCountry();
        if (cc == null || cc.length() != 2) return "🌍";
        return new String(Character.toChars(0x1F1E6 + cc.charAt(0) - 'A'))
                + new String(Character.toChars(0x1F1E6 + cc.charAt(1) - 'A'));
    }
}
