package com.rankrush.app;

import android.app.Activity;
import android.graphics.*;
import android.os.Bundle;
import android.view.*;
import android.content.*;
import android.widget.Toast;
import java.util.*;

public final class MainActivity extends Activity {
    public static MainActivity APP;
    private final ApiClient api = new ApiClient();
    private RankView view; private LeaderboardRepository repo; private int lastScore; private int lastRank;
    @Override public void onCreate(Bundle b){ super.onCreate(b); APP=this; repo=new LeaderboardRepository(this); view=new RankView(this); setContentView(view); }

    private static String todayUtc(){
        java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
        f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return f.format(new java.util.Date());
    }
    private void startGame(){
        final GameView g=new GameView(this, System.currentTimeMillis()/86400000L, (score,reactions)->{
            lastScore=score; repo.saveScore(score, todayUtc()); lastRank=repo.rankFor(todayUtc(), score); view.screen=2; setContentView(view); view.invalidate(); api.submit(todayUtc(), score, reactions, (rank,best,err)->{ if(rank!=null){ lastRank=rank; view.invalidate(); }});
        }); setContentView(g); g.start();
    }
    private void share(){
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, "I just hit " + lastScore + "ms on RANKRUSH. My world rank: #" + lastRank + ". Can you beat me?\n#RANKRUSH #BeatTheWorld");
        startActivity(Intent.createChooser(i,"Share your rank"));
    }
    private final class RankView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); int screen=0; RectF r=new RectF();
        RankView(Context c){super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        float d(float x){return x*getResources().getDisplayMetrics().density;}
        void txt(Canvas c,String s,float x,float y,float size,int color,Paint.Align a,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(d(size));p.setTextAlign(a);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
        void round(Canvas c,float l,float t,float rr,float bb,float rad,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawRoundRect(d(l),d(t),d(rr),d(bb),d(rad),d(rad),p);}
        @Override protected void onDraw(Canvas c){
            c.drawColor(Color.rgb(9,10,18)); float w=getWidth()/getResources().getDisplayMetrics().density;
            if(screen==0) home(c,w); else if(screen==1) leaderboard(c,w); else result(c,w);
        }
        void header(Canvas c,float w){txt(c,"RANKRUSH",24,42,17,Color.WHITE,Paint.Align.LEFT,true);txt(c,"LIVE",w-24,42,12,Color.rgb(130,255,190),Paint.Align.RIGHT,true);}
        void home(Canvas c,float w){
            header(c,w); txt(c,"BEAT THE WORLD.",24,94,34,Color.WHITE,Paint.Align.LEFT,true); txt(c,"ONE SHOT. EVERY DAY.",24,126,18,Color.rgb(175,180,205),Paint.Align.LEFT,false);
            round(c,24,154,w-24,392,24,Color.rgb(19,21,33)); txt(c,"TODAY'S DUEL",48,188,12,Color.rgb(180,185,210),Paint.Align.LEFT,true);
            txt(c,"30",48,252,70,Color.WHITE,Paint.Align.LEFT,true); txt(c,"SECONDS",170,248,15,Color.LTGRAY,Paint.Align.LEFT,true); txt(c,"10 rounds · reaction speed",170,273,13,Color.rgb(160,165,185),Paint.Align.LEFT,false);
            round(c,48,302,w-48,364,18,Color.WHITE); txt(c,"PLAY TODAY'S DUEL",w/2,341,15,Color.BLACK,Paint.Align.CENTER,true);
            int best=repo.getBest(); txt(c,best==0?"NO OFFICIAL SCORE YET":"BEST  "+best+"ms",48,430,14,Color.WHITE,Paint.Align.LEFT,true);
            txt(c,"STREAK  "+repo.getStreak()+" 🔥",w-48,430,14,Color.rgb(240,200,120),Paint.Align.RIGHT,true);
            txt(c,"A fair daily challenge for everyone on Earth.",w/2,477,13,Color.rgb(140,145,170),Paint.Align.CENTER,false);
            round(c,24,512,w/2-8,574,18,Color.rgb(24,26,40)); round(c,w/2+8,512,w-24,574,18,Color.rgb(24,26,40));
            txt(c,"LEADERBOARD",w/4,550,13,Color.WHITE,Paint.Align.CENTER,true); txt(c,"HOW IT WORKS",w*0.75f,550,13,Color.WHITE,Paint.Align.CENTER,true);
        }
        void leaderboard(Canvas c,float w){
            header(c,w); txt(c,"WORLD LEADERBOARD",24,92,28,Color.WHITE,Paint.Align.LEFT,true); txt(c,"TODAY · UTC",24,116,12,Color.rgb(145,150,175),Paint.Align.LEFT,true);
            List<LeaderboardRepository.Entry> rows=repo.getDemoLeaderboard(todayUtc(),lastScore); int y=154; int shown=Math.min(rows.size(),9);
            for(int i=0;i<shown;i++){ LeaderboardRepository.Entry e=rows.get(i); if(e.me) round(c,24,y-26,w-24,y+14,14,Color.rgb(42,34,60));
                txt(c,String.valueOf(i+1),38,y,13,Color.rgb(150,155,180),Paint.Align.LEFT,true); txt(c,e.country,72,y+1,16,Color.WHITE,Paint.Align.LEFT,false); txt(c,e.name,108,y,14,e.me?Color.WHITE:Color.rgb(215,218,230),Paint.Align.LEFT,e.me); txt(c,e.score+"ms",w-38,y,14,Color.WHITE,Paint.Align.RIGHT,true); y+=48; }
            txt(c,"Your current rank: #"+(lastRank==0?"—":lastRank),w/2,610,15,Color.rgb(190,195,215),Paint.Align.CENTER,true); 
            round(c,24,636,w-24,692,18,Color.WHITE); txt(c,"BACK",w/2,671,14,Color.BLACK,Paint.Align.CENTER,true);
        }
        void result(Canvas c,float w){
            header(c,w); txt(c,"YOUR RUN IS LOCKED",w/2,112,13,Color.rgb(145,150,175),Paint.Align.CENTER,true); txt(c,lastScore+"ms",w/2,205,76,Color.WHITE,Paint.Align.CENTER,true); txt(c,"WORLD RANK  #"+lastRank,w/2,242,18,Color.rgb(130,255,190),Paint.Align.CENTER,true);
            round(c,24,282,w-24,392,22,Color.rgb(19,21,33)); txt(c,"DAILY STREAK",48,316,11,Color.rgb(150,155,180),Paint.Align.LEFT,true); txt(c,repo.getStreak()+" days",48,352,28,Color.WHITE,Paint.Align.LEFT,true); txt(c,"Come back tomorrow for a new seed.",48,378,12,Color.rgb(155,160,185),Paint.Align.LEFT,false);
            round(c,24,420,w-24,480,18,Color.WHITE); txt(c,"SHARE MY RANK",w/2,458,14,Color.BLACK,Paint.Align.CENTER,true);
            round(c,24,496,w/2-8,554,18,Color.rgb(24,26,40)); round(c,w/2+8,496,w-24,554,18,Color.rgb(24,26,40));
            txt(c,"LEADERBOARD",w/4,532,13,Color.WHITE,Paint.Align.CENTER,true); txt(c,"HOME",w*0.75f,532,13,Color.WHITE,Paint.Align.CENTER,true);
            txt(c,"No retries. No excuses. Just the number.",w/2,596,13,Color.rgb(135,140,165),Paint.Align.CENTER,false);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_UP)return true; float x=e.getX()/getResources().getDisplayMetrics().density,y=e.getY()/getResources().getDisplayMetrics().density,w=getWidth()/getResources().getDisplayMetrics().density;
            if(screen==0){if(y>292&&y<375){ if(todayUtc().equals(repo.getLastDate())) {Toast.makeText(MainActivity.this,"Today's official run is already locked.",Toast.LENGTH_SHORT).show();} else startGame(); return true;} if(y>510&&y<590&&x<w/2){screen=1;invalidate();return true;}}
            else if(screen==1){if(y>620){screen=0;invalidate();return true;}}
            else { if(y>408&&y<492){share();return true;} if(y>490&&y<570&&x<w/2){screen=1;invalidate();return true;} if(y>490&&y<570&&x>=w/2){screen=0;invalidate();return true;}}
            return true;
        }
    }
}
