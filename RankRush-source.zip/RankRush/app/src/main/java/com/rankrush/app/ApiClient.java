package com.rankrush.app;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ApiClient {
    public interface Callback { void done(Integer rank, Integer bestMs, String error); }
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final String base;
    public ApiClient(){base=BuildConfig.API_BASE_URL==null?"":BuildConfig.API_BASE_URL.trim();}
    public boolean enabled(){return !base.isEmpty();}
    public void submit(String day,int score,int[] reactions,Callback cb){
        if(!enabled()){cb.done(null,null,null);return;}
        io.execute(()->{
            try{
                JSONObject body=new JSONObject();
                body.put("day",day); body.put("user_id",userId()); body.put("name","YOU"); body.put("country","XX"); body.put("score_ms",score);
                JSONArray a=new JSONArray(); for(int x:reactions)a.put(x); body.put("reactions",a);
                String out=request("POST","/v1/score",body.toString()); JSONObject o=new JSONObject(out);
                main.post(()->cb.done(o.has("rank")&&!o.isNull("rank")?o.getInt("rank"):null,o.has("bestMs")?o.getInt("bestMs"):null,null));
            }catch(Exception e){main.post(()->cb.done(null,null,e.getMessage()));}
        });
    }
    private String userId(){
        android.content.SharedPreferences p=com.rankrush.app.MainActivity.APP.getSharedPreferences("rankrush",0);
        String id=p.getString("uid",null); if(id!=null)return id; id=UUID.randomUUID().toString(); p.edit().putString("uid",id).apply(); return id;
    }
    private String request(String method,String path,String body)throws Exception{
        URL u=new URL(base.replaceAll("/$","")+path); HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setConnectTimeout(7000);c.setReadTimeout(7000);c.setRequestMethod(method);c.setRequestProperty("Content-Type","application/json");c.setDoInput(true);
        if(body!=null){c.setDoOutput(true);try(OutputStream os=c.getOutputStream()){os.write(body.getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); String out=read(in); if(code<200||code>=300)throw new IOException(out); return out;
    }
    private String read(InputStream in)throws Exception{try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder b=new StringBuilder();String s;while((s=r.readLine())!=null)b.append(s);return b.toString();}}
}
