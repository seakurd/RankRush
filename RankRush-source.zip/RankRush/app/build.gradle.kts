plugins { id("com.android.application") }

android {
    namespace = "com.rankrush.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.rankrush.app"
        minSdk = 23
        targetSdk = 37
        versionCode = 1
        versionName = "1.0.0"
        buildConfigField("String", "API_BASE_URL", "\"\"")
    }

    buildTypes {
        debug { applicationIdSuffix = ".debug"; versionNameSuffix = "-debug" }
        release { isMinifyEnabled = false; isShrinkResources = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
