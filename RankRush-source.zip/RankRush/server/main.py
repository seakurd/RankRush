from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import sqlite3, hashlib, os
from datetime import date

DB = os.getenv('DB_PATH', 'rankrush.db')
app = FastAPI(title='RankRush API', version='1.0')

def db():
    con=sqlite3.connect(DB)
    con.execute('''CREATE TABLE IF NOT EXISTS scores (day TEXT, user_id TEXT, name TEXT, country TEXT, score_ms INTEGER, reactions TEXT, PRIMARY KEY(day,user_id))''')
    return con

class Score(BaseModel):
    day: str
    user_id: str = Field(min_length=3, max_length=80)
    name: str = Field(min_length=1, max_length=24)
    country: str = Field(min_length=2, max_length=8)
    score_ms: int = Field(ge=90, le=10000)
    reactions: list[int] = Field(min_length=10, max_length=10)

@app.get('/health')
def health(): return {'ok': True}

@app.get('/v1/leaderboard')
def leaderboard(day: str, limit: int = 100):
    if limit < 1 or limit > 500: raise HTTPException(400, 'limit')
    con=db(); rows=con.execute('SELECT name,country,score_ms FROM scores WHERE day=? ORDER BY score_ms ASC LIMIT ?', (day,limit)).fetchall(); con.close()
    return {'day':day,'rows':[{'name':n,'country':c,'scoreMs':s,'rank':i+1} for i,(n,c,s) in enumerate(rows)]}

@app.post('/v1/score')
def submit(s: Score):
    if s.day != str(date.today()): raise HTTPException(400, 'day must be server date (UTC in production)')
    if any(x < 90 or x > 10000 for x in s.reactions): raise HTTPException(400, 'reaction out of range')
    if sum(s.reactions)//10 != s.score_ms: raise HTTPException(400, 'score mismatch')
    con=db();
    old=con.execute('SELECT score_ms FROM scores WHERE day=? AND user_id=?',(s.day,s.user_id)).fetchone()
    if old and old[0] <= s.score_ms: con.close(); return {'accepted':False,'bestMs':old[0]}
    con.execute('INSERT OR REPLACE INTO scores(day,user_id,name,country,score_ms,reactions) VALUES(?,?,?,?,?,?)',(s.day,s.user_id,s.name,s.country,s.score_ms,','.join(map(str,s.reactions))))
    con.commit(); rank=con.execute('SELECT COUNT(*)+1 FROM scores WHERE day=? AND score_ms<?',(s.day,s.score_ms)).fetchone()[0]; con.close()
    return {'accepted':True,'bestMs':s.score_ms,'rank':rank}
