# Product strategy

RANKRUSH is designed around three current mobile behaviors: games competing with social/AI for attention, daily missions + achievements + leaderboards for engagement, and a low-friction share loop. Current industry reports show global app installs and sessions growing in H1 2026, while mobile gaming continues to emphasize engagement and live-ops discipline. The MVP therefore minimizes onboarding and makes the social artifact (rank + score) the primary output.

### Core differentiator
Everyone gets the same daily challenge seed. This creates a common global event instead of an endless feed of separate matches.

### Expansion path
- Friend duels and private rooms
- Country and city ladders
- Weekly seasons
- Cosmetic rank frames
- Verified creator challenges
- AI-generated challenge variants
- Play Integrity + server-side scoring validation
