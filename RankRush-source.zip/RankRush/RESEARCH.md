# RANKRUSH — research snapshot (2026-10-02)

## Product signals used

1. Adjust's H1 2026 mobile benchmark reports worldwide installs up 13% YoY and sessions up 5%. Its 2026 report also notes hyper-casual games remained the largest share of gaming installs and emphasizes measuring cross-surface attention and acquisition. Source: https://www.adjust.com/blog/app-trends-2026-update/

2. Unity's 2026 gaming report says surveyed developers most often cited daily rewards/missions (23%), achievements/trophies (22%), and leaderboards (20%) as engagement strategies that increased playtime. Source: https://unity.com/resources/gaming-report

3. Google Play Games Services recommends making leaderboards easy to access and setting score upper bounds so obviously fake scores are discarded. Source: https://developer.android.com/games/pgs/quality

4. Google documents the Play Integrity API as a way to help a backend verify that protected requests come from the genuine app, and recommends combining integrity verdicts with other anti-abuse signals. Standard requests are intended for on-demand checks of user actions/server requests. Sources:
   - https://developer.android.com/google/play/integrity/overview
   - https://developer.android.com/google/play/integrity/standard

5. Firebase supports anonymous Android authentication for low-friction onboarding, but its security guidance says anonymous auth should be treated as warm onboarding and not as a replacement for a durable sign-in method when cross-device persistence matters. Source: https://firebase.google.com/docs/auth/android/anonymous-auth

## Strategic design choice

The MVP is not a generic feed. It is a shared daily event: everyone sees the same deterministic 10-round reaction challenge for that UTC day. The product's social artifact is the rank itself, which can be shared through the native Android share sheet.

This is deliberately narrow: fast first-use, a universal skill, a clear daily reset, a single official run, and a visible leaderboard. The expansion plan is country/city ladders, friend rooms, seasonal frames, creator challenges, AI-generated variants, and production anti-cheat.

## Current implementation status

- Android native MVP UI + gameplay: implemented.
- Local daily leaderboard demo: implemented.
- Streak and personal best: implemented.
- Share loop: implemented.
- Prototype REST backend: implemented in `server/`.
- Online adapter: implemented; set `API_BASE_URL` in `app/build.gradle.kts`.
- Production Play Integrity verification: architecture noted, not enabled in the demo build.
- Production signing / Play Console configuration: not included.
