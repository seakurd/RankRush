# RANKRUSH

A global daily reaction-speed duel: one seed, one official run, one number to share.

## Product loop
Open → play today's 10-round duel → get world rank → share rank card → return tomorrow.

## What is included
- Native Android app (Java, no third-party runtime dependencies)
- Daily deterministic challenge seed
- One official run per UTC day
- Streaks and personal best
- Leaderboard UI with local demo data
- Native Android share sheet
- Prototype FastAPI leaderboard backend
- GitHub Actions workflow that builds the debug APK

## Production hardening
Before launch, connect the app to a real backend, move ranking to server time, and add Play Integrity verification to protected score submissions. Google documents Play Integrity standard requests for checking that server requests come from a genuine app and recommends combining integrity verdicts with other anti-abuse signals.

## Build
Use Android Studio 2026.1.4+ / AGP 9.4.0 / Gradle 9.6 / JDK 17.

The current app ships in offline demo mode because a deployed production API and signing credentials are not embedded in source control. Set `API_BASE_URL` and implement the HTTP client adapter before production.
